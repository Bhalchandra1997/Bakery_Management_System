package Main_Driver;

import java.util.List;
import java.util.Scanner;

import com.pojo.employee;
import com.pojo.product;

import Dao.employeeDaoimpl;

public class employee_test {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		employee e;
		employeeDaoimpl eimpl=new employeeDaoimpl();
		List<employee> al=null;
		
		boolean exit=false;
		int EmpID;
		String fname;
		String lname;
		String Designation ;
		String Date_Of_Joining;
		
		boolean flag;
		
        do {
			
			System.out.println("Please Select One of the below and enter the number according to your selection");
			System.out.println("\n1.Add Employee Details");
			System.out.println("2.Show all Employee");
			System.out.println("3.Update Employee");
			System.out.println("4.Delete Employee");
			System.out.println("5.Exit");
			
			int choice=sc.nextInt();
			sc.nextLine();
			
			switch(choice) {
			
			case 1: 
				
				System.out.println("Enter Employee First name :- ");
				fname = sc.nextLine();
				
				System.out.println("Enter Employee Last Name:- ");
				lname = sc.nextLine();
				
				System.out.println("Enter Employee Designation");
				Designation = sc.nextLine();
				
				System.out.println("Enter Date Of Joining of Employee");
				Date_Of_Joining = sc.nextLine();
				
				e = new employee();
				e.setFname(fname);
				e.setLname(lname);
				e.setDesignation(Designation);
				e.setDate_Of_Joining(Date_Of_Joining);
				
				flag = eimpl.addemployee(e);
				
				if(flag)
					System.out.println("This employee has been successfully added to database");
				else
					System.out.println("Error while adding employee details to table.");
				

			break;

			case 2: 
			
			al=eimpl.showAllemployee();
						
			if(al.isEmpty()||al==null)
				
			System.out.println("No Employee have been added yet...");
			
			else {
							
				for(employee e1:al) {
								
				   if(e1!=null) {
				   
					   System.out.println(e1);
					  
			          }
		            }
	             }
							
			break;
				
			case 3:
				
				System.out.println("Enter Id of employee to be updated...");
				EmpID=sc.nextInt();
				sc.nextLine();
				
				e=eimpl.showemployeeById(EmpID);
				
				if(e==null)
					System.out.println("No employee with this id found! Please try again.");
				else {
					
					System.out.println("-------employee------");
					System.out.println(e);
					
					System.out.println("\nDo you want to continue updating?Enter y for yes and n for no");
					char option=sc.next().charAt(0);
					sc.nextLine();
					
					if(option=='y') {
						
						System.out.println("Enter first name:-");
						fname=sc.nextLine();
						
						System.out.println("Enter last name:- ");
						lname=sc.nextLine();
						
						System.out.println("Enter the Designation");
						Designation = sc.nextLine();
						
						System.out.println("Enter the Date Of Joining");
						Date_Of_Joining= sc.nextLine();
						
						
						e.getFname();
						e.getLname();
						e.getDesignation();
						e.getDate_Of_Joining();
						
						
						
						flag=eimpl.updateemployee(e);
						
						if(flag)
							System.out.println("Employee updated successfully!!!");
						else
							System.out.println("Error while updating employee details.");
						
					}
					else if(option=='n') {
						
						System.out.println("Thank you!!");
					}
					else
						System.out.println("Please enter y for yes and n for no");
					
				}
				
				break;
				
			case 4:
				System.out.println("Enter Id of Employee to be deleted...");
				EmpID=sc.nextInt();
				sc.nextLine();
				
				e=eimpl.showemployeeById(EmpID);
				
				if(e==null)
					System.out.println("No employee with this id found! Please try again.");
				else {
					
					System.out.println("-------Employee------");
					System.out.println(e);
					
					System.out.println("\nAre you sure you want to delete?Enter y for yes and n for no");
					char option=sc.next().charAt(0);
					sc.nextLine();
					
					if(option=='y') {
						
						flag=eimpl.deleteemployee(EmpID);
						
						if(flag)
							System.out.println("Employee deleted successfully !!!");
						else
							System.out.println("Error while deleting employee");
						
					}
					else if(option=='n') {
						
						System.out.println("Thank you!!");
					}
					else
						System.out.println("Please enter y for yes and n for no");
					
				}
				
				break;
				
			
				
			case 5: exit=true;
			System.out.println("Thank you");
			break;
			
			
			default: System.out.println("Please enter number between 1 to 5 according to the options.");
			}
		}while(exit==false);

		sc.close();

	}
	

	

}
