package Main_Driver;

import java.util.List;
import java.util.Scanner;

import com.pojo.product;

import Dao.productDaoimpl;

public class product_test {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		product p = null;
		productDaoimpl pimpl = new productDaoimpl();
		List<product> plist = null;
		
		int productID;
		String pname;
		String description;
		String price;
		String unit;
		
		boolean exit = false, flag;
		do {
			
			System.out.println("\n***** Welcome *****");
			System.out.println("\nPlease Select One of the below and enter the number according to your selection");
			System.out.println("1.Add Product details.");
			System.out.println("2.Show AllProduct/Menu");
			System.out.println("3.Update a Product item.");
			System.out.println("4.Delete Product from menu.");
			System.out.println("5.Search Product item based on name.");
			
			
			int option = sc.nextInt();
			sc.nextLine();
			
			switch(option){
			
			case 1:
				System.out.println("Enter product name :- ");
				pname = sc.nextLine();
				
				System.out.println("Describe the food item in few words :- ");
				description = sc.nextLine();
				
				System.out.println("Enter the Selling Price");
				price = sc.nextLine();
				
				System.out.println("Enter the unit");
				unit = sc.nextLine();
				
				p = new product(pname, description, price, unit);
				
				flag = pimpl.addproduct(p);
				
				if(flag)
					System.out.println("This product has been successfully added to database");
				else
					System.out.println("Error while adding product details to table.");
				
				break;
				
			case 2:
				
				plist = pimpl.showAllproduct();
				
				if(plist != null && plist.isEmpty() != true) {
					System.out.println("----------- Our_Menu -----------");
					System.out.println();
					for(int i=0; i<plist.size(); i++) {
						System.out.println(plist.get(i) +"\n");
					}
					
				}
				else
					
					System.out.println("No product in our menu currently... To be added soon...");
				
				break;
				
			case 3:
				
				System.out.println("Enter the id of product item to be updated.");
				productID = sc.nextInt();
				sc.nextLine();
				
				p = pimpl.showproductById(productID);
				
				if(p != null) {
					
					System.out.println("The item :- \n"+p);
					System.out.println("Are you sure you want to update this product item? Answer in yes or no.");
					String choice = sc.next().toLowerCase();
					sc.nextLine();
					
					if(choice.equals("yes")) {
						System.out.println();
						
						System.out.println("Enter new Product name :- ");
						pname = sc.nextLine();
												
						System.out.println("Describe the product in few words :- ");
						description = sc.nextLine();
						
						System.out.println("Enter the new Selling Price");
						price = sc.nextLine();
						
						System.out.println("Enter the new units of Product");
						unit = sc.nextLine();
						
						p.setPname(pname);
						p.setPrice(price);
						p.setDescription(description);
						
						flag = pimpl.updateproduct(p);
						
						if(flag)
							System.out.println("Product updated successfully..");
						else
							System.out.println("Error while updating..");
						
					}
					else if(choice.equals("no"))
						
						System.out.println("No problem. Please continue with the other option.");
					else
						
						System.out.println("Please enter yes or no only.");
					
				}
				else
					System.out.println("Please check the given id.");
				
				break;
				
			case 4:
				
				System.out.println("Enter the product id of the item to be deleted.");
				productID = sc.nextInt();
				sc.nextLine();
				
				p = pimpl.showproductById(productID);
				
				if(p != null) {
					
					System.out.println("The item :- \n"+p);
					System.out.println("Are you sure you want to delete this product item? Answer in yes or no.");
					String choice = sc.next().toLowerCase();
					sc.nextLine();
					
					if(choice.equals("yes")) {
						System.out.println();
						
						flag = pimpl.deleteproduct(productID);
						
						if(flag)
							System.out.println("product deleted successfully..");
						else
							System.out.println("Error while deleting..");
						
					}
					else if(choice.equals("no"))
						System.out.println("No problem. Please continue with the other option.");
					else
						System.out.println("Please enter yes or no only.");
					
				}
				else
					System.out.println("Please check the given id.");
				
				break;
				
				
			case 5:
				
				System.out.println("Enter the name of product you want :- ");
				pname = sc.nextLine();
				
				plist = pimpl.showproductByName(pname);
				
				if (plist != null && plist.isEmpty() != true) {
					
					System.out.println("The list of items in our menu in "+pname+" option are...\n");
					plist.forEach(i->{
						System.out.println(i);
						System.out.println("_____________________________________________\n");
					});
					
				}
				else
					System.out.println("Please check the given name, we are unable to find given name.");
				

			break;	
			}
			
		}
		while(exit == false);

	}

	
	
	
}
