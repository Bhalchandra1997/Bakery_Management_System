package Main_Driver;


import java.util.List;
import java.util.Scanner;

import com.pojo.sales;

import Dao.salesDaoimpl;

public class sales_test {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		sales s = null;
		//Date d = null;
		salesDaoimpl simpl = new salesDaoimpl();
		List<sales> slist = null;
		
		int salesID;
		String Quantity;
		String Date;
	
		boolean exit = false, flag;
		do {
			
			System.out.println("\n*** Welcome ***");
			System.out.println("\nHow do you want to proceed? Please give input as per the menu given below...");
			System.out.println("1.Add Sales details.");
			System.out.println("2.Show AllSales");
			System.out.println("3.Update a Sales Details.");
			System.out.println("4.Delete Sales Details");
			System.out.println("5.Check Sales by Date");
			System.out.println("6.Exit");
			
			int option = sc.nextInt();
			sc.nextLine();
			
			switch(option){
			
			case 1:
				
				System.out.println("Enter Quantity :- ");
				Quantity = sc.nextLine();
				
				System.out.println("Enter Date :- ");
				Date = sc.nextLine();
				
				s = new sales(Quantity, Date);
				
				flag = simpl.addsales(s);
				
				if(flag)
					System.out.println("This sales has been successfully added to database");
				else
					System.out.println("Error while adding sales details to table.");
				
				break;
				
			case 2:
				
				slist = simpl.showAllsales();
				
				if(slist != null && slist.isEmpty() != true) {
					System.out.println("----------- Our Sales -----------");
					
					System.out.println();
					
					for(int i=0; i<slist.size(); i++) {
						
						System.out.println(slist.get(i) +"\n");
					}
					
				}
				else
					
					System.out.println("No product in our menu currently... To be added soon...");
				
				break;
				
			case 3:
				
				System.out.println("Enter the id of sales to be updated.");
				
				salesID = sc.nextInt();
				sc.nextLine();
				
				s = simpl.showsalesById(salesID);
				
				if(s != null) {
					
					System.out.println("The item :- \n"+s);
					System.out.println("Are you sure you want to update this product item? Answer in yes or no.");
					
					String choice = sc.next().toLowerCase();
					sc.nextLine();
					
					if(choice.equals("yes")) {
						
						System.out.println();
						
						System.out.println("Enter new Quantity :- ");
						Quantity = sc.nextLine();
												
						System.out.println("Enter new Date :- ");
						Date = sc.nextLine();
						
						s.setQuantity(Quantity);
						s.setDate(Date);
						
						flag = simpl.updatesales(s);
						
						if(flag)
							System.out.println("Sales updated successfully..");
						else
							System.out.println("Error while updating..");
						
					}
					else if(choice.equals("no"))
						
						System.out.println("No problem. Please continue with the other option.");
					else
						
						System.out.println("Please enter yes or no only.");
					
				}
				else
					System.out.println("Please check the given id.");
				
				break;
				
			case 4:
				
				System.out.println("Enter the product id of the item to be deleted.");
				salesID = sc.nextInt();
				sc.nextLine();
				
				s = simpl.showsalesById(salesID);
				
				if(s != null) {
					
					System.out.println("The item :- \n"+s);
					System.out.println("Are you sure you want to delete this sales details? Answer in yes or no.");
					String choice = sc.next().toLowerCase();
					sc.nextLine();
					
					if(choice.equals("yes")) {
						System.out.println();
						
						flag = simpl.deletesales(salesID);
						
						if(flag)
							System.out.println("Sales details deleted successfully..");
						else
							System.out.println("Error while deleting..");
						
					}
					else if(choice.equals("no"))
						System.out.println("No problem. Please continue with the other option.");
					else
						System.out.println("Please enter yes or no only.");
					
				}
				else
					System.out.println("Please check the given id.");
				
				break;
				
				
			case 5:
				
				System.out.println("Enter the Date of sales you want :- ");
				Date = sc.nextLine();
				
				slist = simpl.showsalesByDate(Date);
				
				if (slist != null && slist.isEmpty() != true) {
					
					System.out.println("The list of details in our Sales on "+Date+" are...\n");
					slist.forEach(i->{
						System.out.println(i);
						System.out.println("_____________________________________________\n");
					});
					
				}
				else
					System.out.println("Please check the given Date, we are unable to find given Date.");
				
				break;
				
			case 6: exit=true;
			System.out.println("-----------------Thank you-------------------");
			break;
			}
			
		}
		while(exit == false);

	}
}
