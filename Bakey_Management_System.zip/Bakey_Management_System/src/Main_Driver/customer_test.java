package Main_Driver;


import java.util.List;
import java.util.Scanner;


import com.pojo.customer;


import Dao.customerDaoimpl;


public class customer_test {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		customer c;
		customerDaoimpl cimpl=new customerDaoimpl();
		List<customer> al=null;
		
		boolean exit=false;
		int CustID;
		String fname;
		String lname;
		String Contact;
		boolean flag;
			
		do {
			
			System.out.println("Please Select One of the below and enter the number according to your selection");
			System.out.println("\n1.Add Customer Details");
			System.out.println("2.Show all Customer");
			System.out.println("3.Update Customer");
			System.out.println("4.Delete Customer");
			System.out.println("5.Exit");
			
			int choice=sc.nextInt();
			sc.nextLine();
			
			switch(choice) {
			
			case 1: 
				
		    System.out.println("Enter first name:-");
		    fname=sc.nextLine();
					
		    System.out.println("Enter last name:- ");
		    lname=sc.nextLine();
					
			System.out.println("Enter contact:- ");
			Contact=sc.nextLine();
					
			c=new customer();
			c.setFname(fname);
			c.setLname(lname);
			c.setContact(Contact);
					
					
			flag=cimpl.addCustomer(c);
					
			if(flag)
			
				System.out.println("Customer details added successfully!!!");
			
			else
				
				System.out.println("Error while adding details");
					
			break;
			
			case 2: 
			
			al=cimpl.showAllCustomer();
						
			if(al.isEmpty()||al==null)
				
			System.out.println("No Customer have been added yet...");
			
			else {
							
				for(customer c1:al) {
								
				   if(c1!=null) {
				   
					   System.out.println(c1);
					  
			          }
		            }
	             }
							
			break;
				
			case 3:
				
				System.out.println("Enter the id of Customer to be updated.");
				CustID = sc.nextInt();
				sc.nextLine();
				
				c = cimpl.showCustomerById(CustID);
				
				if(c != null) {
					
					System.out.println("The item :- \n"+c);
					System.out.println("Are you sure you want to update this product item? Answer in yes or no.");
					String option = sc.next().toLowerCase();
					sc.nextLine();
					
					if(option.equals("yes")) {
						System.out.println();
						
						System.out.println("Enter new Customer first name :- ");
						fname = sc.nextLine();
												
						System.out.println("Enter new Customer last name :- ");
						lname = sc.nextLine();
						
						System.out.println("Enter new Contact Number");
						Contact = sc.nextLine();
						
						c.setFname(fname);
						c.setLname(lname);
						c.setContact(Contact);
						
						flag = cimpl.updateCustomer(c);
						
						if(flag)
							System.out.println("Customer updated successfully..");
						else
							System.out.println("Error while updating..");
						
					}
					else if(option.equals("no"))
						
						System.out.println("No problem. Please continue with the other option.");
					else
						
						System.out.println("Please enter yes or no only.");
					
				}
				else
					System.out.println("Please check the given id.");
				
				
				break;
				
			case 4:
				System.out.println("Enter Id of Customer to be deleted...");
				CustID=sc.nextInt();
				sc.nextLine();
				
				c=cimpl.showCustomerById(CustID);
				
				if(c==null)
					System.out.println("No customer with this id found! Please try again.");
				else {
					
					System.out.println("-------Customer------");
					System.out.println(c);
					
					System.out.println("\nAre you sure you want to delete?Enter y for yes and n for no");
					char option=sc.next().charAt(0);
					sc.nextLine();
					
					if(option=='y') {
						
						flag=cimpl.deleteCustomer(CustID);
						
						if(flag)
							System.out.println("Customer deleted successfully!!!");
						else
							System.out.println("Error while deleting movie ");
						
					}
					else if(option=='n') {
						
						System.out.println("Thank you!!");
					}
					else
						System.out.println("Please enter y for yes and n for no");
					
				}
				
				break;
				
			
				
			case 5: exit=true;
			System.out.println("-----------------Thank you-------------------");
			break;
			
			
			default: System.out.println("Please enter number between 1 to 5 according to the options in menu.");
			}
		}while(exit==false);

		sc.close();

	}
	
		
}

	
