package DB_Connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnectivity {

	public static Connection makeConnection() {
		
		Connection con = null;
		
        try {
			
			//Register and Load Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Create Connection 
			String user = "root";
			String password = "Raj@12345";
			String url = "jdbc:mysql://localhost:3306/bakery_management_system";
			
			con = DriverManager.getConnection(url, user, password);
			
		}
		catch(Exception e) {
			
			e.printStackTrace();
			
		}
		
		return con;
			
	}

}
