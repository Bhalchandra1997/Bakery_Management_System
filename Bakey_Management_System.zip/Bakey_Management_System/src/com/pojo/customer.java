package com.pojo;

public class customer {

	private int CustID;
	private String fname;
	private String lname;
	private String Contact;
	
	
	public customer() {
		super();
		
	}

	public customer(int custID, String fname, String lname, String contact) {
		super();
		CustID = custID;
		this.fname = fname;
		this.lname = lname;
		Contact = contact;
	}

	public customer(String fname, String lname, String contact) {
		super();
		this.fname = fname;
		this.lname = lname;
		Contact = contact;
	}

	public int getCustID() {
		return CustID;
	}

	public void setCustID(int custID) {
		CustID = custID;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getContact() {
		return Contact;
	}

	public void setContact(String contact) {
		Contact = contact;
	}

	@Override
	public String toString() {
		return "\nCustID=" + CustID + ", \nfname=" + fname + ", \nlname=" + lname + ", \nContact=" + Contact ;
	}
	
	
	
	
	
	
}
