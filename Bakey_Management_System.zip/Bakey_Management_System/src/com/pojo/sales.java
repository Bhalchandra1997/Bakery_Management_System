package com.pojo;

public class sales {

	private int SalesID;
	private String Quantity;
	private String Date;
	

	public sales() {
		super();
		
	}

	public sales(int salesID, String quantity, String date) {
		super();
		SalesID = salesID;
		Quantity = quantity;
		Date = date;
	}

	public sales(String quantity, String date) {
		super();
		Quantity = quantity;
		Date = date;
	}

	public int getSalesID() {
		return SalesID;
	}

	public void setSalesID(int salesID) {
		SalesID = salesID;
	}

	public String getQuantity() {
		return Quantity;
	}

	public void setQuantity(String quantity) {
		Quantity = quantity;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	@Override
	public String toString() {
		return "sales [SalesID=" + SalesID + ", Quantity=" + Quantity + ", Date=" + Date + "]";
	}
	
	
	
}
