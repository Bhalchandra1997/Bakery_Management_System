package com.pojo;

public class employee {
	
	private int EmpId;
	private String fname;
	private String lname;
	private String Designation;
	private String Date_Of_Joining;
	
	
	
	public employee() {
		super();
		
	}

	public employee(int empId, String fname, String lname, String designation, String date_Of_Joining) {
		super();
		EmpId = empId;
		this.fname = fname;
		this.lname = lname;
		Designation = designation;
		Date_Of_Joining = date_Of_Joining;
	}

	public employee(String fname, String lname, String designation, String date_Of_Joining) {
		super();
		this.fname = fname;
		this.lname = lname;
		Designation = designation;
		Date_Of_Joining = date_Of_Joining;
	}

	public int getEmpId() {
		return EmpId;
	}

	public void setEmpId(int empId) {
		EmpId = empId;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public String getDate_Of_Joining() {
		return Date_Of_Joining;
	}

	public void setDate_Of_Joining(String date_Of_Joining) {
		Date_Of_Joining = date_Of_Joining;
	}

	@Override
	public String toString() {
		return "employee [EmpId=" + EmpId + ", fname=" + fname + ", lname=" + lname + ", Designation=" + Designation
				+ ", Date_Of_Joining=" + Date_Of_Joining + "]";
	}
	
	
	

}
