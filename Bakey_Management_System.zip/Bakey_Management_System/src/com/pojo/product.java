package com.pojo;

public class product {

	private int productID;
	private String pname;
	private String Description;
	private String price;
	private String unit;
	
	
	public product() {
		super();
		
	}

	public product(int productID, String pname, String description, String price, String unit) {
		super();
		this.productID = productID;
		this.pname = pname;
		Description = description;
		this.price = price;
		this.unit = unit;
	}

	public product(String pname, String description, String price, String unit) {
		super();
		this.pname = pname;
		Description = description;
		this.price = price;
		this.unit = unit;
	}

	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	@Override
	public String toString() {
		return "product [productID=" + productID + ", pname=" + pname + ", Description=" + Description + ", price="
				+ price + ", unit=" + unit + "]";
	}
	
	
	
	
}
