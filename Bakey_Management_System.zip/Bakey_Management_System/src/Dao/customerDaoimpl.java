package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


import com.pojo.customer;

import DB_Connection.DBConnectivity;

public class customerDaoimpl implements customerDao {
	
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	String sql=null;
	customer c=null;
	List<customer> clist=null;


	@Override
	public boolean addCustomer(customer c) {
		
		con=DBConnectivity.makeConnection();
		sql="insert into customer(fname, lname, Contact) values (?,?,?)";
		
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, c.getFname());
			ps.setString(2, c.getLname());
			ps.setString(3, c.getContact());
			
			
			int i=ps.executeUpdate();
			
			if(i>0)
				return true;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally {
			try {
				con.close();
				ps.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		}
		return false;
	}
		

	@Override
	public boolean updateCustomer(customer c) {
		
		con = DBConnectivity.makeConnection();
		sql = "update customer set fname=?,lname=?,Contact=? where CustID=?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, c.getFname());
			ps.setString(2, c.getLname());
			ps.setString(3, c.getContact());
			ps.setInt(4, c.getCustID());
			
			int i = ps.executeUpdate();
			
			if(i>0)
				return true;
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean deleteCustomer(int CustID) {
		
		con=DBConnectivity.makeConnection();
		sql="delete from customer where CustID=?";
		
		try {
			ps=con.prepareStatement(sql);
			ps.setInt(1, CustID);
			
			int i=ps.executeUpdate();
			
			if(i>0)
				return true;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally {
			try {
				con.close();
				ps.close();
			} catch (SQLException e) {
		
				e.printStackTrace();
			}
			
		}
		return false;
	}

	@Override
	public List<customer> showAllCustomer() {
		
		con=DBConnectivity.makeConnection();
		
		sql="select * from customer;";
		
		try {
			ps=con.prepareStatement(sql);
			
			rs=ps.executeQuery();
			
			clist=new ArrayList<>();
			
			while(rs.next()) {
				
				c=new customer();
				c.setCustID(rs.getInt(1));
				c.setFname(rs.getString(2));
				c.setLname(rs.getString(3));
				c.setContact(rs.getString(4));
				
				
				clist.add(c);
			}
			
			return clist;
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		finally {
			try {
				con.close();
				ps.close();
			} 
			catch (SQLException e) {
			
				e.printStackTrace();
			}
			
		}	
		
		return null;
	}

	@Override
	public customer showCustomerById(int CustID) {
		
		con=DBConnectivity.makeConnection();
		sql="select * from customer where custId=?";
		
		try {
			ps=con.prepareStatement(sql);
			ps.setInt(1, CustID);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				
				c=new customer(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
				
				return c;
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally {
			
			try {
				con.close();
				ps.close();
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
		}
		return null;
	}


	
		
      
}
