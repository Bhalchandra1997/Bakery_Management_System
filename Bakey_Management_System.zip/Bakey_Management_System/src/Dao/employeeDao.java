package Dao;

import java.util.List;


import com.pojo.employee;

public interface employeeDao {

	public boolean addemployee(employee e);
	public boolean updateemployee (employee e);
	public boolean deleteemployee (int EmpID);
	public List<employee> showAllemployee();
	public employee showemployeeById(int EmpID);

}
