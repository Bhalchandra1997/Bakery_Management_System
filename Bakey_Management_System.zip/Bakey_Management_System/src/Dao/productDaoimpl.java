package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pojo.product;

import DB_Connection.DBConnectivity;

public class productDaoimpl implements productDao{

	Connection con = null;
	PreparedStatement ps = null;
	String sql = null;
	ResultSet rs = null;
	product p = null;
	List<product> plist = null;
	
	@Override
	public boolean addproduct(product p) {
		
		con = DBConnectivity.makeConnection();
		sql = "insert into product(pname,Description,price,unit) values (?,?,?,?)";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, p.getPname());
			ps.setString(2, p.getDescription());
			ps.setString(3, p.getPrice());
			ps.setString(4,p.getUnit());
			
			int i = ps.executeUpdate();
			
			if(i>0)
				return true;
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean updateproduct(product p) {
	
		con = DBConnectivity.makeConnection();
		sql = "update product set pname=?,description=?,price=?, unit=? where productID=?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, p.getPname());
			ps.setString(2, p.getDescription());
			ps.setString(3, p.getPrice());
            ps.setString(4, p.getUnit());
			ps.setInt(5, p.getProductID());
			
			int i = ps.executeUpdate();
			
			if(i>0)
				return true;
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean deleteproduct(int productID) {
	
		con = DBConnectivity.makeConnection();
		sql = "delete from product where productID=?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, productID);
			
			int i = ps.executeUpdate();
			
			if(i>0)
				return true;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<product> showAllproduct() {
		
		con = DBConnectivity.makeConnection();
		sql = "select * from product";
		
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			
			plist = new ArrayList<product>();
			
			while(rs.next()) {
				
				p = new product();
				p.setProductID(rs.getInt("productId"));
				p.setPname(rs.getString("pname"));
				p.setPrice(rs.getString("price"));
				p.setDescription(rs.getString("description"));
				p.setUnit(rs.getString("unit"));
				plist.add(p);
				
			}
			
			return plist;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public product showproductById(int productID) {
		
		con = DBConnectivity.makeConnection();
		sql = "select * from product where productID=?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1,productID);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				
				p = new product();
				p.setProductID(rs.getInt("productID"));
				p.setPname(rs.getString("pname"));
				p.setDescription(rs.getString("Description"));
				p.setPrice(rs.getString("price"));
				p.setUnit(rs.getString("unit"));

				return p;
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<product> showproductByName(String pname) {
		
		con = DBConnectivity.makeConnection();
		sql = "select * from product where pname like ?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, "%"+pname+"%");
			
			plist = new ArrayList<product>();
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				
				p = new product();
				p.setProductID(rs.getInt("productID"));
				p.setPname(rs.getString("pname"));
				p.setDescription(rs.getString("description"));
				p.setPrice(rs.getString("price"));
				p.setUnit(rs.getString("unit"));
				plist.add(p);
				
			}
			
			return plist;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	

	
}
