package Dao;

import java.util.List;

import com.pojo.product;

public interface productDao {

	public boolean addproduct(product p);
	public boolean updateproduct (product p);
	public boolean deleteproduct (int productID);
	public List<product> showAllproduct();
	public product showproductById(int productID);
	public List<product> showproductByName(String pname);

}
