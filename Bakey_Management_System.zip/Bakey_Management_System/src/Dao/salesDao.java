package Dao;

import java.util.List;


import com.pojo.sales;

public interface salesDao {

	public boolean addsales(sales s);
	public boolean updatesales (sales s);
	public boolean deletesales (int salesID);
	public List<sales> showAllsales();
	public sales showsalesById(int salesID);
	public List<sales> showsalesByDate(String Date);

}
