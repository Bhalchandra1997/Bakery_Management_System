package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pojo.employee;

import DB_Connection.DBConnectivity;

public class employeeDaoimpl implements employeeDao{

	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	String sql=null;
	employee e=null;
	List<employee> elist=null;

	@Override
	public boolean addemployee(employee e) {
		
		con = DBConnectivity.makeConnection();
		sql = "insert into employee(fname,lname,Designation,Date_Of_Joining) values (?,?,?,?)";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, e.getFname());
			ps.setString(2, e.getLname());
			ps.setString(3, e.getDesignation());
			ps.setString(4, e.getDate_Of_Joining());
			
			int i = ps.executeUpdate();
			
			if(i>0)
				return true;
			
		}
		catch (Exception f) {
			f.printStackTrace();
		}

			return false;
	}

	@Override
	public boolean updateemployee(employee e) {
		
		con = DBConnectivity.makeConnection();
		sql = "update employee set fname=?,lname=?,Designation=?,Date_Of_Joining=? where EmpID=?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, e.getFname());
			ps.setString(2, e.getLname());
			ps.setString(3, e.getDesignation());
            ps.setString(4, e.getDate_Of_Joining());
			ps.setInt(5, e.getEmpId());
			
			int i = ps.executeUpdate();
			
			if(i>0)
				return true;
			
		} catch (SQLException f) {
		
			f.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean deleteemployee(int EmpID) {
		
		con = DBConnectivity.makeConnection();
		sql = "delete from employee where EmpID=?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, EmpID);
			
			int i = ps.executeUpdate();
			
			if(i>0)
				return true;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<employee> showAllemployee() {
		
		con = DBConnectivity.makeConnection();
		sql = "select * from employee";
		
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			
			elist = new ArrayList<employee>();
			
			while(rs.next()) {
				
				e = new employee();
				e.setEmpId(rs.getInt("EmpID"));
				e.setFname(rs.getString("Fname"));
				e.setLname(rs.getString("Lname"));
				e.setDesignation(rs.getString("Designation"));
				e.setDate_Of_Joining(rs.getString("Date_Of_Joining"));
				
				
				elist.add(e);
				
			}
			
			return elist;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public employee showemployeeById(int EmpID) {
		
		con = DBConnectivity.makeConnection();
		sql = "select * from employee where EmpID=?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1,EmpID);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				
				e = new employee();
				e.setEmpId(rs.getInt("EmpID"));
				e.setFname(rs.getString("Fname"));
				e.setLname(rs.getString("Designation"));
				e.setDate_Of_Joining(rs.getString("Date_Of_Joining"));

				return e;
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}


		return null;
	}

}
