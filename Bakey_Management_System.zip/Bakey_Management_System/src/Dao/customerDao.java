package Dao;

import java.util.List;

import com.pojo.customer;

public interface customerDao {

	public boolean addCustomer(customer c);
	public boolean updateCustomer (customer c);
	public boolean deleteCustomer (int CustID);
	public List<customer> showAllCustomer();
	public customer showCustomerById(int CustID);
	
}
