package Dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pojo.product;
import com.pojo.sales;

import DB_Connection.DBConnectivity;

public class salesDaoimpl implements salesDao{

	Connection con = null;
	PreparedStatement ps = null;
	String sql = null;
	ResultSet rs = null;
	sales s = null;
	List<sales> slist = null;
	
	@Override
	public boolean addsales(sales s) {
		
		con = DBConnectivity.makeConnection();
		sql = "insert into sales(Quantity,Date) values (?,?)";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, s.getQuantity());
			ps.setString(2, s.getDate());
			
			
			int i = ps.executeUpdate();
			
			if(i>0)
				return true;
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean updatesales(sales s) {
		
		con = DBConnectivity.makeConnection();
		sql = "update sales set Quantity=?,Date=? where SalesID=?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, s.getQuantity());
			ps.setString(2, s.getDate());
			ps.setInt(3, s.getSalesID());
			
			
			int i = ps.executeUpdate();
			
			if(i>0)
				return true;
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean deletesales(int salesID) {
		
		con = DBConnectivity.makeConnection();
		sql = "delete from sales where SalesID=?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, salesID);
			
			int i = ps.executeUpdate();
			
			if(i>0)
				return true;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public List<sales> showAllsales() {
		
		con = DBConnectivity.makeConnection();
		sql = "select * from sales";
		
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			
			slist = new ArrayList<sales>();
			
			while(rs.next()) {
				
				s = new sales();
				s.setSalesID(rs.getInt("SalesID"));
				s.setQuantity(rs.getString("Quantity"));
				s.setDate(rs.getString("Date"));
				
				
				slist.add(s);
				
			}
			
			return slist;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public sales showsalesById(int salesID) {
	
		con = DBConnectivity.makeConnection();
		sql = "select * from sales where SalesID=?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1,salesID);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				
				s = new sales();
				s.setSalesID(rs.getInt("SalesID"));
				s.setQuantity(rs.getString("Quantity"));
				s.setDate(rs.getString("Date"));
				
				return s;
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<sales> showsalesByDate(String Date) {
		
		con = DBConnectivity.makeConnection();
		sql = "select * from sales where Date like ?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, "%"+Date+"%");
			
			slist = new ArrayList<sales>();
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				
				s = new sales();
				s.setSalesID(rs.getInt("SalesID"));
				s.setQuantity(rs.getString("Quantity"));
				s.setDate(rs.getString("Date"));
				
				slist.add(s);
				
			}
			
			return slist;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	

}
